SpeedSignFinder
===============

Use your Smartphone to improve mapping data for speed sign location in your area


This is in BETA. 

This is an implementation of OpenCV as such requires OpenCV Manager from Google Play! https://play.google.com/store/apps/details?id=org.opencv.engine



*Background*:
Most public (government) agencies are under resourced and the task of continuously maintaining spacial (map) data is given low priority. It is very expensive to send an employee out to survey the world, so it just isn't done. That is a good thing as the money (your tax dollars) is spent on better causes, fixing roads, building bridges etc.

Unfortunately this means that you, a member of the public LOSE OUT, as without good data, decisions as to where to put the bridge or which road to fix, are basically just guesstimates.

There is a win/win option. As you and I are already driving out and about with our sophisticated survey equipment, our smart phone, we can do the data capture as a side-effect of our normal day.

*The App: what is does*:
This app scans the road ahead as you drive (too/from work for example), once it detects a speed sign it logs its location, that's it,

